#include <stdio.h>
#include <stdlib.h>

typedef struct mundo {
   int x;
   char y;
} mundo;

typedef struct mundo_invertido {
   char y;
   int x;
} mundo_invertido;

void imprime_mundo (mundo * arr, int n)
{
  int i;
  
  for (i=0;i<10;i++) {
    printf("%d %c\n", arr[i].x, arr[i].y);
  }
  printf("\n");
}

void imprime_mundo_invertido (mundo_invertido * arr, int n)
{
  int i;
  
  for (i=0;i<10;i++) {
    printf("%d %c\n", arr[i].x, arr[i].y);
  }
  printf("\n");
}

int main ()
{
  mundo arr[10];
  mundo_invertido arr_inv[10];
  int i;
  FILE * fp;
  
  for (i=0;i<10;i++) {
    arr[i].x = 2*i + 1;
    arr[i].y = 'A' + i;
  }
  printf("Estrutura original: \n");
  imprime_mundo(arr, 10);

  /* escrevendo arquivo binário */
  fp = fopen("dados.bin", "wb");
  fwrite(arr, sizeof(mundo), 10, fp);
  fclose(fp);
  
  /* alterando a estrutura */
  for (i=0;i<9;i++) {
    arr[i].x = arr[i+1].x;
    arr[i].y = arr[i+1].y;
  }
  printf("Estrutura alterada: \n");
  imprime_mundo(arr, 10);
  
  /* lendo arquivo binário para estrutura correta */
  fp = fopen("dados.bin", "rb");
  fread(arr, sizeof(mundo), 10, fp);
  fclose(fp);
  
  /* lendo arquivo binário para estrutura invertida */
  fp = fopen("dados.bin", "rb");
  fread(arr_inv, sizeof(mundo_invertido), 10, fp);
  fclose(fp);
  
  printf("Estrutura recuperada do arquivo: \n");
  imprime_mundo(arr, 10);
  
  printf("Estrutura lida em um struct diferente: \n");
  imprime_mundo_invertido(arr_inv, 10);
  
  
  return 0;
}
